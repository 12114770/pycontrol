package keys

const (
	AdminPassword = "adminPassword"
	JwtSecret     = "jwtSecretKey"
)
