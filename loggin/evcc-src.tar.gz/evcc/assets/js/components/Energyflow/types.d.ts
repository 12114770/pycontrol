interface Pv {
  title?: string;
  power: number;
}
