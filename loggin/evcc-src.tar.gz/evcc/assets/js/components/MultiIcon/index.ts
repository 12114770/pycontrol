import MultiIcon from "./MultiIcon.vue";

export default MultiIcon;
