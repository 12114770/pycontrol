export interface Grid {
  power?: number;
}
