export interface Provider {
  title: string;
  loggedIn: boolean;
  loginPath: string;
  logoutPath: string;
}
