package api

// Custom meter/charger/vehicle type
const Custom = "custom"
